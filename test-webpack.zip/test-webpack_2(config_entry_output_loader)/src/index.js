import test from './main'
import './index.css'
console.log('Current date:' + new Date());
test();

