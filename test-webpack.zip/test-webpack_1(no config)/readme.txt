--create a npm project, and it will generate a package.json file
npm init -y

--install webpack and cli package, --save: add to package.json, -dev: add to package.json's devDependencies
npm i webpack@4.0.0 webpack-cli@3.3.12 --save-dev

--create index.html file
--create dist/ folder
--create src/index.js; src/main.js
--import <script src='./dist/index.js'/> in index.html

--run package command: npx webpack [entry js] -o [output js], will generate index.js in dist folder
npx webpack src/index.js -o dist/index.js