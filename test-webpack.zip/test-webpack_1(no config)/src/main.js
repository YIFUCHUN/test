function test(){
    console.log("main.test function");
}
export default test;