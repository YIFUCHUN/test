import test from './main'
console.log('Current date:' + new Date());
test();

