const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'index.js'
  },
  module: {
      rules: [
          {
              test: /\.css$/,
              use: ['style-loader', 'css-loader']
          }
      ]
  },
  plugins:[
    new HtmlWebpackPlugin({
      template: path.join(__dirname, '/index.html')
    })
  ],

  devServer: {
    contentBase: path.join(__dirname, 'dist'),
    compress: true, //gzip
    port: 3000,
    // host: '0.0.0.0',
    hot: true, // hot deploy, need install webpack.HotModuleReplacementPlugin
    // https: true, // open https
    open: true, //open browser after started
    // proxy:{
    //   '/api':{
    //     target:'http://localhost:3001',
    //     pathRewrite: {'^/api':''}
    //   }
    // }
  }

};